#!/bin/sh

echo "Plugin Un-Installed!"; #NOT! :)

exit 0;
